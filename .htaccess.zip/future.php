<?php
include('includes/header.php');
?>
<!DOCTYPE html>
<html>
<head>
  <title>KC Cottrell</title>
  <meta name="description" content="Mobile UI minimal simple Landing page with toggle menu">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="styles.css">
  </head>

  <body>
  <div class="outersquare">
    <span class="menu-trigger"></span>
    
      <div>
        <h1>Hello.</h1>
      </div>
  </div>
  
  </body>


</html>